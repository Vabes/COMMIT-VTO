const Discord = require("discord.js")
const Command = require("../Structure/Command")

module.exports = new Command({

    name: "ping",
    description: "Permet de connaître la latence du bot",
    utilisation: "ping",
    permission: "Aucune",
    category: "Information",

    async run(bot, message, args, db) {

        message.delete()

        const startTimeDB = Date.now()

        db.query(`SELECT * FROM serveur WHERE guildID = ${message.guild.id}`, async (err, req) => {

            const endTimeDB = Date.now()

            const startTime = Date.now()

            await message.channel.send(`En cours...`).then(async msg => {

                const endTime = Date.now()

                try{
                    await msg.edit(`\`Latence du bot\` : ${endTime - startTime} ms\n\`Latence de l'API de Discord\` : ${bot.ws.ping} ms\n\`Latence de la base de données\` : ${endTimeDB - startTimeDB} ms\n\n ${message.author}`)
                } catch (err) {
                    await message.edit(`\`Latence du bot\` : ${endTime - startTime} ms\n\`Latence de l'API de Discord\` : ${bot.ws.ping} ms\n\`Latence de la base de données\` : ${endTimeDB - startTimeDB} ms\n\n ${message.author}`)
                }
            })
        })
    }
})