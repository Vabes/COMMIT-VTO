const { REST } = require("@discordjs/rest")
const { Routes } = require("discord-api-types/v9")
const { SlashCommandBuilder } = require("@discordjs/builders");
const { token } = require("../config");

module.exports = async(bot) => {

    const commands = [

        new SlashCommandBuilder()
        .setName("ping")
        .setDescription("Permet de connaître la latence du bot")
    ]

    const rest = new REST({ version: '9' }).setToken(token)

    for (let i = 0; i < bot.guilds.cache.size; i++) {

        await rest.put(Routes.applicationGuildCommands(bot.user.id, bot.guilds[i].id), { body: commands });
    }

    console.log("Les Slashs commandes ont été créées avec succès !")
}