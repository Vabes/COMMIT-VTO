const Client = require("./Structure/Client");
const { token } = require("./config");
const bot = new Client();

bot.start(token)